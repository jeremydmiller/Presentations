create function mt_immutable_timestamp(value text)
  returns timestamp with time zone
immutable
language sql
as $$
select value::timestamptz
$$;

