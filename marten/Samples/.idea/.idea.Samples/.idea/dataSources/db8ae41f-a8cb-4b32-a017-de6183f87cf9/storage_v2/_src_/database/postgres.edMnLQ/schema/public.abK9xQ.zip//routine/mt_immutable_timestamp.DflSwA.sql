CREATE FUNCTION mt_immutable_timestamp(value text)
  RETURNS timestamp with time zone
IMMUTABLE
LANGUAGE SQL
AS $$
select value::timestamptz
$$;

