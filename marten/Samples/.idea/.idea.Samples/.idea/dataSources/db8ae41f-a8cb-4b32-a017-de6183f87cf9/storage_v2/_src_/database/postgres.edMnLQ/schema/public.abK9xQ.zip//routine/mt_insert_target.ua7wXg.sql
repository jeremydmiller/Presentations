CREATE FUNCTION mt_insert_target(doc jsonb, docdotnettype character varying, docid uuid, docversion uuid)
  RETURNS uuid
LANGUAGE plpgsql
AS $$
BEGIN
INSERT INTO public.mt_doc_target ("data", "mt_dotnet_type", "id", "mt_version", mt_last_modified) VALUES (doc, docDotNetType, docId, docVersion, transaction_timestamp());

  RETURN docVersion;
END;
$$;

