CREATE FUNCTION mt_mark_event_progression(name character varying, last_encountered bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
INSERT INTO public.mt_event_progression (name, last_seq_id) VALUES (name, last_encountered)
  ON CONFLICT ON CONSTRAINT pk_mt_event_progression
  DO UPDATE SET last_seq_id = last_encountered;

END;
$$;

